# To Do
- [ ] Associate a new expansion panel with the add button in the treatment record component
- [ ] Add sign in component
- [ ] Use WebSocket to implement the instant message part of first aid component
- [ ] Patterns - Errors
- [ ] Patterns - Help & feedback
- [ ] Patterns - Navigation drawer
- [ ] Patterns - Navigational transitions 
