// user info
export const SET_BASE_INFO = 'SET_BASE_INFO'

// patient
export const SET_CURRENT_PATIENT = 'SET_CURRENT_PATIENT'

// followup info
export const SET_FOLLOWUP = 'SET_FOLLOWUP'

// login
export const SET_LOGIN = 'SET_LOGIN'

// doc
export const SET_TIP = 'SET_TIP'
export const SET_LOADING = 'SET_LOADING'
export const SET_MODAL = 'SET_MODAL'
export const SET_MODAL_MSG = 'SET_MODAL_MSG'
